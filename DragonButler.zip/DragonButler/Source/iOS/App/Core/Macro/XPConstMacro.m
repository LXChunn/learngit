//
//  XPConstMacro.m
//  Huaban
//
//  Created by huangxinping on 4/25/15.
//  Copyright (c) 2015 iiseeuu.com. All rights reserved.
//

#import "XPConstMacro.h"

#pragma mark -
NSString *const kXPHeaderRefreshingText = @"正在刷新...";
NSString *const kXPFooterRefreshingText = @"正在加载...";

#pragma mark -
NSString *const kXPDataErrorDescription = @"无更多数据";
NSString *const kXPDataLoadingDescription = @"加载中...";
