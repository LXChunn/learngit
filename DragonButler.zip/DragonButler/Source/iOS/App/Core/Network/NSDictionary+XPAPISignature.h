//
//  NSDictionary+XPAPISignature.h
//  XPApp
//
//  Created by xinpinghuang on 12/15/15.
//  Copyright © 2015 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (XPAPISignature)

- (NSString *)signature;

@end
