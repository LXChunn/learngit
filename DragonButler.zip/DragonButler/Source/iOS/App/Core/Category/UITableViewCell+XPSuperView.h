//
//  UITableViewCell+XPSuperView.h
//  XPApp
//
//  Created by huangxinping on 15/10/21.
//  Copyright © 2015年 iiseeuu.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (XPSuperView)

- (UIView *)suitableSuperView;

@end
