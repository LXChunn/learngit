//
//  NSString+RACSignal.h
//  XPApp
//
//  Created by huangxinping on 15/11/13.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ReactiveCocoa/ReactiveCocoa.h>

@interface NSString (RACSignal)

// Sends each line in the string.
@property (nonatomic, strong, readonly) RACSignal *rac_lineSignal;

@end
