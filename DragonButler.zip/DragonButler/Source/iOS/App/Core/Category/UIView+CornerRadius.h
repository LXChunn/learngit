//
//  UIView+CornerRadius.h
//  TestTextView
//
//  Created by jy on 16/2/26.
//  Copyright © 2016年 jy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (CornerRadius)
@property (nonatomic,assign) IBInspectable CGFloat cornerRadius;
@end
