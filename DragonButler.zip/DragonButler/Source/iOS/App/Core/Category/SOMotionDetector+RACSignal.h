//
//  SOMotionDetector+RACSignal.h
//  XPApp
//
//  Created by huangxinping on 15/11/17.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import <SOMotionDetector/SOMotionDetector.h>

@class RACSignal;
@interface SOMotionDetector (RACSignal)

- (RACSignal *)rac_motionTypeSignal;
- (RACSignal *)rac_locationSignal;
- (RACSignal *)rac_accelerationSignal;

@end
