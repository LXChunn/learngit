//
//  UIView+XPNib.h
//  XPApp
//
//  Created by huangxinping on 15/11/13.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (XPNib)

+ (instancetype)viewFromNib;

@end
