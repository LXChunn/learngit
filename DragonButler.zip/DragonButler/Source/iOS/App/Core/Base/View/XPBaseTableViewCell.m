//
//  XPBaseTableViewCell.m
//  Huaban
//
//  Created by huangxinping on 4/23/15.
//  Copyright (c) 2015 iiseeuu.com. All rights reserved.
//

#import "XPBaseTableViewCell.h"
#import "XPBaseView.h"

@implementation XPBaseTableViewCell

- (void)awakeFromNib
{
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)bindViewModel:(XPBaseViewModel *)viewModel
{
    XPLogError(@"Opps，you must implement sub class.");
}

@end
