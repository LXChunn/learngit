//
//  XPBaseTableViewController.h
//  Huaban
//
//  Created by huangxinping on 4/21/15.
//  Copyright (c) 2015 iiseeuu.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XPBaseTableViewController : UITableViewController

@end
