//
//  XPBaseTableViewController.m
//  Huaban
//
//  Created by huangxinping on 4/21/15.
//  Copyright (c) 2015 iiseeuu.com. All rights reserved.
//

#import "XPBaseTableViewController.h"

@interface XPBaseTableViewController ()

@end

@implementation XPBaseTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupTableView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Setup tableview
- (void)setupTableView
{
    [self.tableView reloadData];
}

@end
