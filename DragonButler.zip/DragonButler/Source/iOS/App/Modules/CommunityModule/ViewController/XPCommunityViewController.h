//
//  XPCommunityViewController.h
//  XPApp
//
//  Created by jy on 16/1/14.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPCommunityViewController : XPBaseViewController


@end
