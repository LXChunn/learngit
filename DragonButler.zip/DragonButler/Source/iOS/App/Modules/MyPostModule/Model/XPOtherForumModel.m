//
//  XPOtherForumModel.m
//  XPApp
//
//  Created by CaoShunQing on 16/2/22.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPOtherForumModel.h"


@interface XPOtherForumModel ()


@end

@implementation XPOtherForumModel

- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

@end 
