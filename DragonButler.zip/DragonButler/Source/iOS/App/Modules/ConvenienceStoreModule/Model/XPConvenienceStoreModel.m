//
//  XPConvenienceStoreModel.m
//  XPApp
//
//  Created by iiseeuu on 16/1/15.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPConvenienceStoreModel.h"

@interface XPConvenienceStoreModel ()


@end

@implementation XPConvenienceStoreModel

- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

@end 
