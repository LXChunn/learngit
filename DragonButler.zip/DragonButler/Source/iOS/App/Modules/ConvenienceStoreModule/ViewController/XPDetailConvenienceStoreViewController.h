//
//  XPDetailConvenienceStoreViewController.h
//  XPApp
//
//  Created by iiseeuu on 16/1/18.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"
#import "XPConvenienceStoreModel.h"


@interface XPDetailConvenienceStoreViewController : XPBaseViewController

@property (nonatomic,strong)XPConvenienceStoreModel *detaiModel;

@end
