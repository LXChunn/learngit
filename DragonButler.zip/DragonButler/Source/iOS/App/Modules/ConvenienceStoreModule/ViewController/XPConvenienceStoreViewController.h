//
//  XPConvenienceStoreViewController.h
//  XPApp
//
//  Created by iiseeuu on 16/1/15.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPConvenienceStoreViewController : XPBaseViewController


@end
