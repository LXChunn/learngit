//
//  NSString+XPAPI_ConvenienceStore.h
//  XPApp
//
//  Created by iiseeuu on 16/1/15.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPI_ConvenienceStore)

+ (NSString *)api_conveniencestore_path;

@end
