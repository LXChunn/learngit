//
//  XPDetailImageConvenienceStoreTableViewCell.h
//  XPApp
//
//  Created by iiseeuu on 16/1/20.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseTableViewCell.h"
#import "XPConvenienceStoreModel.h"
@interface XPDetailImageConvenienceStoreTableViewCell : XPBaseTableViewCell

@property (nonatomic,strong)XPConvenienceStoreModel *detailModel;

@end
