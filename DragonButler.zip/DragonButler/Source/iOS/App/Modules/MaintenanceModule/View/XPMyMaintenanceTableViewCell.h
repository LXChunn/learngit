//
//  XPMaintenanceTableViewCell.h
//  XPApp
//
//  Created by iiseeuu on 15/12/24.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseModel.h"
#import "XPBaseTableViewCell.h"

@interface XPMyMaintenanceTableViewCell : XPBaseTableViewCell

- (void)bindModel:(XPBaseModel *)model;

@end
