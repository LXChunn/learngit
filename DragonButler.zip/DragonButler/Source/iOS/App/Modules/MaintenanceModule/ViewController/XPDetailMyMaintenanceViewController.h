//
//  XPDetailMyMaintenanceViewController.h
//  XPApp
//
//  Created by iiseeuu on 15/12/25.
//  Copyright 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"
#import "XPMyMaintenanceModel.h"

@interface XPDetailMyMaintenanceViewController : XPBaseViewController

@property (nonatomic, strong) XPMyMaintenanceModel *detailModel;

@end
