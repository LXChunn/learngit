//
//  XPMaintenanceViewController.h
//  XPApp
//
//  Created by xinpinghuang on 12/23/15.
//  Copyright 2015 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPMaintenanceViewController : XPBaseViewController

@end
