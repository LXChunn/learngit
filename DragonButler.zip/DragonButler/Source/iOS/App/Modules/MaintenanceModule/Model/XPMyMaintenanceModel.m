//
//  XPMyMaintenanceModel.m
//  XPApp
//
//  Created by iiseeuu on 15/12/25.
//  Copyright 2015年 ShareMerge. All rights reserved.
//

#import "XPMyMaintenanceModel.h"

@interface XPMyMaintenanceModel ()

@end

@implementation XPMyMaintenanceModel

- (instancetype)init
{
    if(self = [super init]) {
    }
    
    return self;
}

@end
