//
//  XPOtherFavoriateModel.m
//  XPApp
//
//  Created by CaoShunQing on 16/2/23.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPOtherFavoriateModel.h"


@interface XPOtherFavoriateModel ()


@end

@implementation XPOtherFavoriateModel

- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

@end 
