//
//  XPMyOtherFavoriteCell.h
//  XPApp
//
//  Created by CaoShunQing on 16/2/23.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XPMyOtherFavoriteCell : UITableViewCell

- (void)bindModel:(id)model;

+ (NSInteger)heightForCell:(NSArray *)arry;

@end
