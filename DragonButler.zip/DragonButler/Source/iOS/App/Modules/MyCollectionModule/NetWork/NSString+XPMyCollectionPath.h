//
//  NSString+XPMyCollectionPath.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/8.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPMyCollectionPath)

+ (NSString *)api_my_favorites;//查询我的收藏

+ (NSString *)api_my_otherFavorites;//我的收藏（其他）
@end
