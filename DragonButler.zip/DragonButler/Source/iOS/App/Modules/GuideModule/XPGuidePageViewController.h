//
//  XPGuidePageViewController.h
//  XPApp
//
//  Created by jy on 16/1/25.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPGuidePageViewController : XPBaseViewController


@end
