//
//  XPAnnouncementhold.m
//  XPApp
//
//  Created by iiseeuu on 15/12/19.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPPropertyBillModel.h"

@implementation XPPropertyBillModel

@end