//
//  XPAnnouncementhold.h
//  XPApp
//
//  Created by iiseeuu on 15/12/19.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseModel.h"

@interface XPPropertyBillModel : XPBaseModel

@property NSString *amount;
@property NSString *billId;
@property NSString *createdAt;
@property NSString *status;
@property NSString *title;
@property NSString *type;
@property NSString *dollarAmount;

@end
