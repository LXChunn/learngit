//
//  XPAPIpath+UtilityBills.h
//  XPApp
//
//  Created by Mac OS on 15/12/21.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface  NSString (XPAPIpath_PropertyBill)

+ (NSString *)api_propertybill_path;

+ (NSString *)api_billpayment_url_path;

+ (NSString *)api_billpayment_path;

@end
