//
//  XPJFZDViewController.h
//  XPApp
//
//  Created by Mac OS on 15/12/19.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPPropertyBillViewController : XPBaseViewController
@property NSInteger pageIndex;

@end
