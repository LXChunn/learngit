//
//  NSString+XPAPIPath_Login.h
//  XPApp
//
//  Created by huangxinping on 15/9/23.
//  Copyright © 2015年 iiseeuu.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_Login)

+ (NSString *)api_verication_code_path;
+ (NSString *)api_login_path;
+ (NSString *)api_user_info_path;

@end
