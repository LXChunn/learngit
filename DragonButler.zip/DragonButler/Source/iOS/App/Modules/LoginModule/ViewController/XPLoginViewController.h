//
//  XPLoginViewController.h
//  XPApp
//
//  Created by huangxinping on 15/9/23.
//  Copyright © 2015年 iiseeuu.com. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPLoginViewController : XPBaseViewController

@end
