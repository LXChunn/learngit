//
//  XPCommnityTableViewCell.h
//  XPApp
//
//  Created by iiseeuu on 15/12/21.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseModel.h"
#import "XPBaseTableViewCell.h"

@interface XPCommnityTableViewCell : XPBaseTableViewCell

- (void)bindModel:(XPBaseModel *)model;

@end
