//
//  XPAnnouncementViewController.h
//  XPApp
//
//  Created by iiseeuu on 15/12/19.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPAnnouncementViewController : XPBaseViewController

@end
