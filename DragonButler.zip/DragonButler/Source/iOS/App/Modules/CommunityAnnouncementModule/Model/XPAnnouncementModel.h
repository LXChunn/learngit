//
//  XPAnnouncementhold.h
//  XPApp
//
//  Created by iiseeuu on 15/12/19.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseModel.h"

@interface XPAnnouncementModel : XPBaseModel

@property NSString *communityAnnouncementId;
@property NSString *content;
@property NSString *createdAt;
@property NSString *themePicUrl;
@property NSString *title;
@property NSString *type;
@property NSArray * picUrls;

@end
