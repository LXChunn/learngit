//
//  XPSecondHandItemsListModel.m
//  XPApp
//
//  Created by jy on 15/12/29.
//  Copyright 2015年 ShareMerge. All rights reserved.
//

#import "XPSecondHandItemsListModel.h"

@interface XPSecondHandItemsListModel ()

@end

@implementation XPSecondHandItemsListModel

- (instancetype)init
{
    if(self = [super init]) {
    }
    
    return self;
}

@end
