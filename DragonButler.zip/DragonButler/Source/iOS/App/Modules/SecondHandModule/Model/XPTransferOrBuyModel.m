//
//  XPTransferOrBuyModel.m
//  XPApp
//
//  Created by jy on 15/12/30.
//  Copyright 2015年 ShareMerge. All rights reserved.
//

#import "XPTransferOrBuyModel.h"

@interface XPTransferOrBuyModel ()

@end

@implementation XPTransferOrBuyModel

- (instancetype)init
{
    if(self = [super init]) {
    }
    
    return self;
}

@end
