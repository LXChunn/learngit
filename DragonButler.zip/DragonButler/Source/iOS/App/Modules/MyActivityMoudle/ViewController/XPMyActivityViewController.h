//
//  XPMyActivityViewController.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/7.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPMyActivityViewController : XPBaseViewController

@end
