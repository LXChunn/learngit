//
//  XPMyactivitiyDetailCell.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/9.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XPMyactivitiyDetailCell : UITableViewCell

@end
