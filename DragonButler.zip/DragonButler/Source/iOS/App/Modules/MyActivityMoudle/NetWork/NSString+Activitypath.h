//
//  NSString+Activitypath.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/7.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Activitypath)

+ (NSString *)api_my_participation;

@end
