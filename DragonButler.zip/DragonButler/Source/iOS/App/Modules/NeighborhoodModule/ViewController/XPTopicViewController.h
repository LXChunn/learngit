//
//  XPTopicViewController.h
//  XPApp
//
//  Created by iiseeuu on 15/12/29.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPTopicViewController : XPBaseViewController

@end
