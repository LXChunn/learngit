//
//  NSString+XPAPIPath_Topic.h
//  XPApp
//
//  Created by iiseeuu on 15/12/30.
//  Copyright 2015年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_Topic)
+ (NSString *)api_topic_path;
+ (NSString *)api_my_participation_path;
@end
