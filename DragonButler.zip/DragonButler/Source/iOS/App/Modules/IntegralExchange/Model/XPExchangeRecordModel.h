//
//  XPExchangeRecordModel.h
//  XPApp
//
//  Created by CaoShunQing on 16/2/25.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseModel.h"

@interface XPExchangeRecordModel : XPBaseModel
@property (nonatomic, assign) NSInteger point;
@property (nonatomic, assign) NSInteger time;

@end
