//
//  XPExchangeRecordModel.m
//  XPApp
//
//  Created by CaoShunQing on 16/2/25.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPExchangeRecordModel.h"


@interface XPExchangeRecordModel ()


@end

@implementation XPExchangeRecordModel

- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

@end 
