//
//  NSString+XPAPIPath_IntegralExchange.h
//  XPApp
//
//  Created by CaoShunQing on 16/2/24.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_IntegralExchange)

+ (NSString *)api_Integral_Exchange;

+ (NSString *)api_points_exchange_records;
@end
