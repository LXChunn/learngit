//
//  XPDetailViewController.h
//  XPApp
//
//  Created by Mac OS on 15/12/28.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"
#import "XPComplaintModel.h"

@interface XPDetailViewController : XPBaseViewController

@property (nonatomic, strong) XPComplaintModel *detailModel;

@end
