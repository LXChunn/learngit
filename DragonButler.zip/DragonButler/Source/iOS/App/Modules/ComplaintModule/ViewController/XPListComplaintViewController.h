//
//  XPListComplaintViewController.h
//  XPApp
//
//  Created by Mac OS on 15/12/28.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPListComplaintViewController : XPBaseViewController

@end
