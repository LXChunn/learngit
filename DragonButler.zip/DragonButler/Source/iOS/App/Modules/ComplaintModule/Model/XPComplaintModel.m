//
//  XPComplaintModel.m
//  XPApp
//
//  Created by Mac OS on 15/12/28.
//  Copyright © 2015年 ShareMerge. All rights reserved.
//

#import "XPComplaintModel.h"

@interface XPComplaintModel ()

@end

@implementation XPComplaintModel

- (instancetype)init
{
    if(self = [super init]) {
    }
    
    return self;
}

@end
