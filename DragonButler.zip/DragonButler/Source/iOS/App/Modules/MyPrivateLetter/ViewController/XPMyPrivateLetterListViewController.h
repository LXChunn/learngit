//
//  XPMyPrivateLetterListViewController.h
//  XPApp
//
//  Created by jy on 16/1/9.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPMyPrivateLetterListViewController : XPBaseViewController

@end
