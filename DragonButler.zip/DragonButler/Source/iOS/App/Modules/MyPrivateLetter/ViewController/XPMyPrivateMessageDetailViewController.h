//
//  XPMyPrivateMessageDetailViewController.h
//  XPApp
//
//  Created by jy on 16/1/9.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPAuthorModel.h"
#import "XPBaseViewController.h"

@interface XPMyPrivateMessageDetailViewController : XPBaseViewController

@property (nonatomic, strong) XPAuthorModel *userModel;

@end
