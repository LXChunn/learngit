//
//  XPMessageDetailModel.m
//  XPApp
//
//  Created by jy on 16/1/9.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPMessageDetailModel.h"

@interface XPMessageDetailModel ()

@end

@implementation XPMessageDetailModel

- (instancetype)init
{
    if(self = [super init]) {
    }
    
    return self;
}

@end
