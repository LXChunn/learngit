//
//  XPHappyLifeViewController.h
//  XPApp
//
//  Created by jy on 16/1/13.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPHappyLifeViewController : XPBaseViewController


@end
