//
//  XPCreditCardViewController.h
//  XPApp
//
//  Created by jy on 16/1/18.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPCreditCardViewController : XPBaseViewController


@end
