//
//  NSString+XPAPIPath_BankAdvertisements.h
//  XPApp
//
//  Created by iiseeuu on 16/1/12.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_BankAdvertisements)

+ (NSString *)api_bankadvertisements_path;

@end
