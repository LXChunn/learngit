//
//  XPHousekeepingNewsViewController.h
//  XPApp
//
//  Created by jy on 16/2/16.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPHousekeepingNewsViewController : XPBaseViewController

@end
