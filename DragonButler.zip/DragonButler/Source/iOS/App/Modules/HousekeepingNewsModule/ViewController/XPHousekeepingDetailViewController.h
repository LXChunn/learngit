//
//  XPHousekeepingDetailViewController.h
//  XPApp
//
//  Created by jy on 16/2/23.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPHousekeepingDetailViewController : XPBaseViewController
@property (nonatomic,strong) NSString *housekeepingItemId;
@property (nonatomic,assign) BOOL isChange;
@end
