//
//  XPAddHousekeepingOfContentCell.m
//  XPApp
//
//  Created by jy on 16/2/22.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPAddHousekeepingOfContentCell.h"

@interface XPAddHousekeepingOfContentCell ()


@end

@implementation XPAddHousekeepingOfContentCell

- (void)awakeFromNib {
    
}


@end
