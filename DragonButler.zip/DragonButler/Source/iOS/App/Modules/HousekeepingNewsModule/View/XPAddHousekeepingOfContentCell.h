//
//  XPAddHousekeepingOfContentCell.h
//  XPApp
//
//  Created by jy on 16/2/22.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XPBaseTableViewCell.h"
#import <XPTextView.h>

@interface XPAddHousekeepingOfContentCell : XPBaseTableViewCell

@property (weak, nonatomic) IBOutlet XPTextView *contentTextView;

@end
