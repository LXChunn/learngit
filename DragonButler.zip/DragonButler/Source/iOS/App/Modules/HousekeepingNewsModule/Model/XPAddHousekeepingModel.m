//
//  XPAddHousekeepingModel.m
//  XPApp
//
//  Created by jy on 16/2/22.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPAddHousekeepingModel.h"


@interface XPAddHousekeepingModel ()


@end

@implementation XPAddHousekeepingModel

- (instancetype)init {
	if (self = [super init]) {
        _title = @"";
        _phone = @"";
        _content = @"";
        _pictureUrls = @[];
	}
	return self;
}

@end 
