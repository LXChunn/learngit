//
//  XPHousekeepingDetailModel.m
//  XPApp
//
//  Created by jy on 16/2/23.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPHousekeepingDetailModel.h"


@interface XPHousekeepingDetailModel ()


@end

@implementation XPHousekeepingDetailModel

- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

@end 
