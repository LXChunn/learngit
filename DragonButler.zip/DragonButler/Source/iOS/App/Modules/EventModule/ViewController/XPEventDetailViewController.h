//
//  XPEventDetailViewController.h
//  XPApp
//
//  Created by jy on 16/1/4.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPEventDetailViewController : XPBaseViewController

@property (nonatomic, strong) NSString *forumtopicId;

@end
