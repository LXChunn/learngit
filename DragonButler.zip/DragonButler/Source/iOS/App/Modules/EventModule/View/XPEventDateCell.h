//
//  XPEventDateCell.h
//  XPApp
//
//  Created by jy on 16/1/4.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseTableViewCell.h"

@interface XPEventDateCell : XPBaseTableViewCell

- (void)configureUIWithtitle:(NSString *)title date:(NSString *)date;

@end
