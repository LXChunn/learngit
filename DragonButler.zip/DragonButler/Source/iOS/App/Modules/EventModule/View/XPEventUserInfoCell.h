//
//  XPEventUserInfoCell.h
//  XPApp
//
//  Created by jy on 16/1/9.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseModel.h"
#import "XPBaseTableViewCell.h"

@interface XPEventUserInfoCell : XPBaseTableViewCell

- (void)bindModel:(XPBaseModel *)model;

@end
