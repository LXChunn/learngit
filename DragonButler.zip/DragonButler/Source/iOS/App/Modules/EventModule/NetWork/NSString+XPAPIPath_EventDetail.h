//
//  NSString+XPAPIPath_EventDetail.h
//  XPApp
//
//  Created by jy on 16/1/9.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_EventDetail)

+ (NSString *)api_event_detail_path;

+ (NSString *)api_join_event_path;

@end
