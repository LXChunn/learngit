//
//  XPMyCarpoolDetailCell.h
//  XPApp
//
//  Created by CaoShunQing on 16/2/24.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XPMyCarpoolDetailCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *begainLabel;
@property (weak, nonatomic) IBOutlet UILabel *endLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *remarkLabel;
@end
