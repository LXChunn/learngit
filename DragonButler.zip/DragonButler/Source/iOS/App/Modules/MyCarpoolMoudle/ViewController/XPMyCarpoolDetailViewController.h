//
//  XPMyCarpoolDetailViewController.h
//  XPApp
//
//  Created by CaoShunQing on 16/2/24.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"
#import "XPDetailCarpoolViewController.h"
#import "XPMyCarpoolModel.h"

@interface XPMyCarpoolDetailViewController :XPBaseViewController

@property (nonatomic,strong)XPMyCarpoolModel *detailmodel;

@end
