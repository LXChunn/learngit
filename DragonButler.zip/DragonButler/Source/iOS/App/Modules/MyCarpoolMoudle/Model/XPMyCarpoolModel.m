//
//  XPMyCarpoolModel.m
//  XPApp
//
//  Created by CaoShunQing on 16/2/23.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPMyCarpoolModel.h"


@interface XPMyCarpoolModel ()


@end

@implementation XPMyCarpoolModel

- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

@end 
