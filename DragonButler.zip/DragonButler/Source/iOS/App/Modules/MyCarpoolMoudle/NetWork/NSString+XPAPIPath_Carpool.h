//
//  NSString+XPAPIPath_Carpool.h
//  XPApp
//
//  Created by CaoShunQing on 16/2/23.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_Carpool)

+ (NSString *)api_my_carpoolings_path;

@end
