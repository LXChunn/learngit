//
//  XPLaunchViewModel.h
//  XPApp
//
//  Created by huangxinping on 5/11/15.
//  Copyright (c) 2015 iiseeuu.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XPLaunchViewModel : NSObject

@end
