//
//  XPLaunchView.h
//  XPApp
//
//  Created by huangxinping on 15/8/14.
//  Copyright (c) 2015年 iiseeuu.com. All rights reserved.
//

#import "XPBaseView.h"
#import <UIKit/UIKit.h>

@interface XPLaunchView : XPBaseView

- (void)startAnimation;

@end
