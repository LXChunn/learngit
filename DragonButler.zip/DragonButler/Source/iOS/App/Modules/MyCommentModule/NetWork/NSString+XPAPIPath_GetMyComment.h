//
//  NSString+XPAPIPath_GetMyComment.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/8.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_GetMyComment)

+ (NSString *)api_my_comments;//查询我的评论

@end
