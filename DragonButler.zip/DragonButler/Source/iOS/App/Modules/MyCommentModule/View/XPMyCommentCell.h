//
//  XPMyCommentCell.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/25.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XPMyCommentCell : UITableViewCell
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *nickNameWidthLayout;

@end
