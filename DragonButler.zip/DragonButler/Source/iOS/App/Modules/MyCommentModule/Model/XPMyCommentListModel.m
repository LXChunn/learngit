//
//  XPMyCommentListModel.m
//  XPApp
//
//  Created by jy on 16/1/9.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPMyCommentListModel.h"

@interface XPMyCommentListModel ()

@end

@implementation XPMyCommentListModel

- (instancetype)init
{
    if(self = [super init]) {
    }
    
    return self;
}

@end
