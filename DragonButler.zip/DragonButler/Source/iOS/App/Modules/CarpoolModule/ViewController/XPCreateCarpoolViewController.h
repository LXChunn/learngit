//
//  XPCreateCarpoolViewController.h
//  XPApp
//
//  Created by iiseeuu on 16/2/22.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"


@interface XPCreateCarpoolViewController : XPBaseViewController
@property (nonatomic,assign) BOOL isAdd;

@end
