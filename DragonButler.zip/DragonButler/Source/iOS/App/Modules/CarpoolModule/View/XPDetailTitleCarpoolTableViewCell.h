//
//  XPDetailTitleCarpoolTableViewCell.h
//  XPApp
//
//  Created by iiseeuu on 16/2/26.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseTableViewCell.h"
#import "XPCarpoolModel.h"
@interface XPDetailTitleCarpoolTableViewCell : XPBaseTableViewCell

@property(nonatomic,strong)XPCarpoolModel *detailModel;

@end
