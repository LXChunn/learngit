//
//  XPCarpoolModelModel.m
//  XPApp
//
//  Created by iiseeuu on 16/2/22.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import "XPCarpoolModel.h"


@interface XPCarpoolModel ()


@end

@implementation XPCarpoolModel

- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

@end 
