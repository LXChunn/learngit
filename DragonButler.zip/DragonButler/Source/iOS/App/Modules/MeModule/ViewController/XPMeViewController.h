//
//  XPMeViewController.h
//  XPApp
//
//  Created by huangxinping on 15/10/17.
//  Copyright © 2015年 iiseeuu.com. All rights reserved.
//

#import "XPBaseViewController.h"
#import <UIKit/UIKit.h>

@interface XPMeViewController : XPBaseViewController

@end
