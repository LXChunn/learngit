//
//  XPMeHeadView.m
//  XPApp
//
//  Created by jy on 16/1/5.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPMeHeadView.h"

@interface XPMeHeadView ()

@end

@implementation XPMeHeadView

@end
