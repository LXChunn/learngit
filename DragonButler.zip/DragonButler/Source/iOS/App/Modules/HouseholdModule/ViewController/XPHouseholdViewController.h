//
//  XPHouseholdViewController.h
//  XPApp
//
//  Created by xinpinghuang on 12/15/15.
//  Copyright 2015 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"

@interface XPHouseholdViewController : XPBaseViewController

@end
