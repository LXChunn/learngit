//
//  NSString+XPAPIPath_Household.h
//  XPApp
//
//  Created by xinpinghuang on 12/15/15.
//  Copyright 2015 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_Household)

+ (NSString *)api_bind_house_hold_path;

@end
