//
//  NSString+XPAPIPath_Favouractivities.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/18.
//  Copyright 2016年 ShareMerge. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XPAPIPath_Favouractivities)

+(NSString *)api_ccb_activities;

@end
