//
//  XPMyFavActivityCell.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/18.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XPMyFavActivityCell : UITableViewCell

- (void)bindModel:(id)model;

- (void)detailBindModel:(id)model;
@end
