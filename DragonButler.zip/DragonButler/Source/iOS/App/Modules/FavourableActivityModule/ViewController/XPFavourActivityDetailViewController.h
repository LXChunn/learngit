//
//  XPFavourActivityDetailViewController.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/18.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"
#import "XPCcbActivitiesModel.h"

@interface XPFavourActivityDetailViewController : XPBaseViewController
@property (nonatomic,strong)XPCcbActivitiesModel *sourceModel;
@end
