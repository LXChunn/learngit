//
//  XPFavouActivityViewController.h
//  XPApp
//
//  Created by CaoShunQing on 16/1/18.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import "XPBaseViewController.h"
@interface XPFavouActivityViewController : XPBaseViewController
@end
