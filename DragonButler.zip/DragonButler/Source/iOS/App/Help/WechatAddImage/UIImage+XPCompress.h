//
//  UIImage+XPCompress.h
//  XPApp
//
//  Created by xinpinghuang on 12/24/15.
//  Copyright © 2015 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (XPCompress)

- (NSData *)xp_compress;

@end
