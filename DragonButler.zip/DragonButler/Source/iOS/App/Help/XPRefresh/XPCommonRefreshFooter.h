//
//  XPCommonRefreshFooter.h
//  XPApp
//
//  Created by jy on 16/1/13.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface XPCommonRefreshFooter : MJRefreshBackStateFooter

@end
