//
//  XPShareCollectionViewCell.h
//  XPApp
//
//  Created by jy on 16/1/12.
//  Copyright © 2016年 ShareMerge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XPShareCollectionViewCell : UICollectionViewCell
@property (nonatomic, nonatomic) UIImageView *iconImageView;
@property (nonatomic, nonatomic) UILabel *titleLabel;

@end
