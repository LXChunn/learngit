//
//  XPDeleteActivity.h
//  XPApp
//
//  Created by xinpinghuang on 12/24/15.
//  Copyright © 2015 ShareMerge. All rights reserved.
//

#import "XPBaseShareActivity.h"

@interface XPDeleteActivity : XPBaseShareActivity

@end
