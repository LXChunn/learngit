//
//  View3.h
//  RespondChain
//
//  Created by xinpinghuang on 3/1/16.
//  Copyright © 2016 huangxinping. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View3 : UIView

@end
