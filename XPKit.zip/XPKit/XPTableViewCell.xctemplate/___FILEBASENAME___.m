//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import "XP___VARIABLE_classnamed___TableViewCell.h"
#import <ReactiveCocoa/ReactiveCocoa.h>
#import <XPKit/XPKit.h>

@interface XP___VARIABLE_classnamed___TableViewCell ()


@end

@implementation XP___VARIABLE_classnamed___TableViewCell

#pragma mark - Life Circle
- (void)awakeFromNib
{
}

#pragma mark - Delegate

#pragma mark - Event Responds

#pragma mark - Public Interface

#pragma mark - Private Methods

#pragma mark - Getter & Setter

@end 
