//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import "XP___VARIABLE_classnamed___Storage.h"


@interface XP___VARIABLE_classnamed___Storage ()


@end

@implementation XP___VARIABLE_classnamed___Storage

#pragma mark - Life Circle
- (instancetype)init {
	if (self = [super init]) {

	}
	return self;
}

#pragma mark - Public Interface

#pragma mark - Private Methods

#pragma mark - Getter & Setter

@end 
