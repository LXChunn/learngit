//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import "XPAPIManager.h"

@interface XPAPIManager (___VARIABLE_categorynamed___)


- (RACSignal *)list; // Oops, it's example! so you can remove this line.

@end
