//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

#import "XPAPIManager+Analysis.h"
#import "NSDictionary+XPAPIParameters.h"
#import "XPAPIManager+___VARIABLE_categorynamed___.h"
#import "NSString+XPAPIPath____VARIABLE_categorynamed___.h"

@implementation XPAPIManager (___VARIABLE_categorynamed___)

// Oops, it's example! so you can remove this function.
- (RACSignal *)list 
{
    return [[[[[self rac_GET:[NSString api_list_path]
                parameters  :[@{
                                 }
                               fillDeviceInfo]] map:^id (id value) {
        return [self analysisRequest:value];
    }] flattenMap:^RACStream *(id value) {
        if([value isKindOfClass:[NSError class]]) {
            return [RACSignal error:value];
        }
        // you can parse it, use model class.
        return value;
    }] logError] replayLazily];
}


@end 
